/*
 * © Bugaev Ivan
 * This code is protected by copyright.
*/

var classBody = 'body';

// Preloader

function BivPreloaderStart() {
    $('#bivPreloader').show();
}

function BivPreloaderStop() {
    setTimeout(function(){
        $('#bivPreloader').fadeOut(300);
    },300);
}

BivPreloaderStart();

$(window).load(function () {
    BivPreloaderStop();
});

// Loading images

function BivBackgroundImage() {
    $('.biv-background').each(function(){
        imgUrl = $(this).data('src');
        $(this).css({'backgroundImage': 'url('+imgUrl+')'});
    });
}

BivBackgroundImage();

// Scroll to block

function BivScrolling(id) {
    $target = $('#'+id);
    $("html, body").stop().animate({
        'scrollTop': $target.offset().top
    }, 1000, 'swing', function () {
    });
}

var sectionId = 1;

function OpenSection(id) {
        $('#itemBtn'+sectionId).removeClass('active');
        $('#itemContent'+sectionId).removeClass('active');
        $('#itemBtn'+id).addClass('active');
        $('#itemContent'+id).addClass('active');
        sectionId = id;
        BivScrolling('doc');
}